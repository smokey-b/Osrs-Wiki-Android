# OSRS Wiki — Android APK Project

Target URL: https://oldschool.runescape.wiki
Package ID: com.osrswiki.mobile
Version: 1.0.0

## Option 1: Build APK in the Cloud (No Android Studio Needed)
1. Create a new repository on GitHub and push this unzipped folder.
2. Open the **Actions** tab on GitHub and run **Build OSRS Wiki Android APK** (or it runs automatically on push).
3. Download the compiled `osrs-wiki-debug-apk` zip artifact containing `app-debug.apk` and install it on your Android device.

## Option 2: Build Locally with Android Studio or Gradle
1. Open this folder in **Android Studio** (Hedgehog or newer) or ensure JDK 17 + Android SDK 35 are installed.
2. Run:
   ```bash
   gradle assembleDebug
   ```
3. Install the generated APK at `app/build/outputs/apk/debug/app-debug.apk` onto your phone via USB (`adb install`) or file transfer.
